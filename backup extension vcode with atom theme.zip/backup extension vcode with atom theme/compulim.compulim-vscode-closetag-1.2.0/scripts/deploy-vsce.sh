npx vsce publish -p $VSCE_TOKEN
