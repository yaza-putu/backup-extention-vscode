# VSCode .env syntax highlighting

A port of [DotENV](https://github.com/zaynali53/DotENV) for vscode.

![Example](https://github.com/mikestead/vscode-dotenv/raw/master/images/screenshot.png)

### Acknowledgements

- [Zayn Ali](https://github.com/zaynali53) for [DotENV](https://github.com/zaynali53/DotENV)
- [motdotla](https://github.com/motdotla/dotenv) for the logo
